# Core visual search algorithm
